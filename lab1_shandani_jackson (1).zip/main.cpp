#include <iostream>
#include <fstream>
#include <iomanip> // for setw()
#include <string>

using namespace std;

const int MAX_SIZE = 100;

// Class to hold record data
class Record {
public:
    // Constructor
    Record() {}
    Record(const string& carID, const string& model, const string& manufacturer, int quantity, double price)
        : carID(carID), model(model), manufacturer(manufacturer), quantity(quantity), price(price) {}

    // Getter functions
    string getCarID() const { return carID; }
    string getModel() const { return model; }
    string getManufacturer() const { return manufacturer; }
    int getQuantity() const { return quantity; }
    double getPrice() const { return price; }

private:
    string carID;
    string model;
    string manufacturer;
    int quantity;
    double price;
};

// Helper function to check if a string consists of numeric characters only
bool isNumeric(const string& str) {
    return str.find_first_not_of("0123456789") == string::npos;
}

// Helper function to check if a string consists of alphabetic characters only
bool isAlpha(const string& str) {
    for (char c : str) {
        if (!isalpha(c)) {
            return false;
        }
    }
    return true;
}

// Helper function to check if a string consists of alphanumeric characters only
bool isAlphaNumeric(const string& str) {
    for (char c : str) {
        if (!isalnum(c)) {
            return false;
        }
    }
    return true;
}

// Function prototypes
void getData(Record inventory[], int& size, const string& filename);
void print(const Record inventory[], int size);
bool isValidRec(const Record& record);
void printBadRecords(const Record inventory[], int size);

int main() {
    Record inventory[MAX_SIZE];
    int size = 0;
    getData(inventory, size, "inventory.txt");

    int choice = 0;
    while (choice != 3) {
        cout << "\nMenu:\n";
        cout << "1. Print all inventory\n";
        cout << "2. Print bad records\n";
        cout << "3. Quit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                print(inventory, size);
                break;
            case 2:
                printBadRecords(inventory, size);
                break;
            case 3:
                cout << "Exiting program.\n";
                break;
            default:
                cout << "Invalid choice. Please try again.\n";
                break;
        }
    }

    return 0;
}

// Function to read from a file into an array of structures
void getData(Record inventory[], int& size, const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error opening file: " << filename << endl;
        return;
    }

    // Check if the file is empty using peek()
    if (file.peek() == ifstream::traits_type::eof()) {
        cout << "File is empty." << endl;
        return;
    }

    string carID, model, manufacturer;
    int quantity;
    double price;
    while (file >> carID >> model >> manufacturer >> quantity >> price && size < MAX_SIZE) {
        Record record(carID, model, manufacturer, quantity, price);
        inventory[size++] = record;
    }

    file.close();
}

// Function to print the array of structures
void print(const Record inventory[], int size) {
    cout << setw(10) << "Car ID" << setw(15) << "Model" << setw(20) << "Manufacturer" << setw(20) << "Quantity" << setw(20) << "Price" << endl;
    for (int i = 0; i < size; ++i) {
        cout << setw(10) << inventory[i].getCarID() << setw(15) << inventory[i].getModel() << setw(20) << inventory[i].getManufacturer()
             << setw(20) << inventory[i].getQuantity() << setw(20) << fixed << setprecision(2) << inventory[i].getPrice() << endl;
    }
}

// Function to validate a record
bool isValidRec(const Record& record) {
    // Validate car ID
    if (record.getCarID().length() != 7 ||
        !isNumeric(record.getCarID().substr(0, 3)) ||
        !isAlpha(record.getCarID().substr(3, 2)) ||
        record.getCarID().substr(5, 2).find_first_of('O') != string::npos) {
        return false;
    }

    // Validate model
    if (record.getModel().length() < 3 || !isAlphaNumeric(record.getModel())) {
        return false;
    }

    // Validate price
    if (record.getPrice() <= 15000.00) {
        return false;
    }

    // All conditions passed, record is valid
    return true;
}


// Function to print bad records
void printBadRecords(const Record inventory[], int size) {
    ofstream errorFile("error.txt");
    if (!errorFile.is_open()) {
        cout << "Error opening error file.\n";
        return;
    }

    cout << "Bad Records:\n";
    errorFile << setw(10) << "Car ID" << setw(15) << "Model" << setw(20) << "Manufacturer" << setw(20) << "Quantity" << setw(20) << "Price" << endl;
    cout << setw(10) << "Car ID" << setw(15) << "Model" << setw(20) << "Manufacturer" << setw(20) << "Quantity" << setw(20) << "Price" << endl;

    for (int i = 0; i < size; ++i) {
        if (!isValidRec(inventory[i])) {
            cout << setw(10) << inventory[i].getCarID() << setw(15) << inventory[i].getModel() << setw(20) << inventory[i].getManufacturer()
                 << setw(20) << inventory[i].getQuantity() << setw(20) << fixed << setprecision(2) << inventory[i].getPrice() << endl;

            errorFile << setw(10) << inventory[i].getCarID() << setw(15) << inventory[i].getModel() << setw(20) << inventory[i].getManufacturer()
                      << setw(20) << inventory[i].getQuantity() << setw(20) << fixed << setprecision(2) << inventory[i].getPrice() << endl;
        }
    }

    errorFile.close();
    cout << "\nBad records written to error.txt\n";
}
